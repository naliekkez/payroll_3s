<?php
	include 'includes/session.php';

	if(isset($_POST['add'])){
		$branch_name = $_POST['branch_name'];
		
		$sql = "INSERT INTO branch (name) VALUES ('$branch_name')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Branch added successfully';
			echo $branch_name;
		}
		else{
			$_SESSION['error'] = $conn->error;

		}

	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: branch.php');
?>